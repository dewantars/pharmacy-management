export interface MailInterface {}

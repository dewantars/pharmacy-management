import { Module } from '@nestjs/common';
import { DatabaseService } from './database.service.js';
import { ConfigModule } from '@nestjs/config';

@Module({
  imports: [ConfigModule],
  providers: [DatabaseService],
})
export class DatabaseModule {}

export class CreateFinancialReportDto {}

export class CreateOperationalReportDto {}
